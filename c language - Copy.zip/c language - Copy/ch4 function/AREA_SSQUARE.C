#include<stdio.h>
#include<math.h>

int main (){
    float a,b;
    int side;
    printf("what is the area of square\n");
scanf("%d",&side);
 printf("the area is %f",pow(side,2));
    return 0;
}
