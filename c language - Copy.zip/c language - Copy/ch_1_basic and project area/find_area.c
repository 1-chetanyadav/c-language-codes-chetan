#include <stdio.h>
int main (){
float breadth,length;

 
printf("only use interger (2,3,4,1,) \n what is breadth of rectangle ");
scanf("%f",&breadth);
printf("what is height of rectangle ");
scanf("%f",&length);
printf("code by chetan > the area of your rectangle is %f",length*breadth);


return 0;
}

// for simple no user interaction

// int breath=2,height=9 ;
// int area=breath*height;
// printf("the area is %d",area);