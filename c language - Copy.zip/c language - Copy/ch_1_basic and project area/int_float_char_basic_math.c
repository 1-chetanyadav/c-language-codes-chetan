#include <stdio.h>
int main()
{
    int a = 4;
    float b = 2.3;
    char c = 'g';
    int d = 5;
    float e = 6.3;
    printf("the value of a is %d \n" , a);
    printf("the value of b is %f \n" , b);
    printf("the value of c is %c \n" , c);
    printf("the value of a+d is %d \n" , a+d);
    printf("the value of a*d is %d \n" , a*d);
    printf("the value of b/e is %f \n" , b/e);
    

    return 0;
}

