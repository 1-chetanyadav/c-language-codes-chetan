#include <stdio.h>
// int main()
// {
//     int year;

//     float remindera;
//     float reminderb;

//     printf("type a year\n");
//     scanf("%d", &year);
//     // printf("%f remainder \n", year/4);

//     if (((year % 4 == 0) && (year % 100 ! == 0)) || (year % 400 == 0))

//     {
//         printf("leap year");
//     }

//     else
//     {
//         printf(" not leap");
//     }

//     return 0;
// }