#include <stdio.h>
int main()
{
    float a;
    printf("write a number\n", a);
    scanf("%f", &a);
    printf("if it will divided by 97 then reminder is %f", a / 97);
    return 0;
}