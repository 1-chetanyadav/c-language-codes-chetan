#include <stdio.h>
int main(){
    int count=0;
    printf("your counting start now");
    scanf("%f",&count);
  while(0<1);
    return 0;  
    
}