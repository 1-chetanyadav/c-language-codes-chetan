#include<stdio.h>
int main ()
    {
int x=2,y=3,z=3,r=1;
// 3*x/y-z+r
printf("%d",3*x/y-z+r);
return 0;
    }
