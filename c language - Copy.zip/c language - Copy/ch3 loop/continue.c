#include <stdio.h>
int main(){
    int skip=3;
    int count=20;
    int start=0;
    // printf("write a number you want to print from 1-100\n");
    // scanf("%d",&skip);
   
        while (start!=skip)
        {
        printf(">>>%d\n",skip);
        continue;
        }
        // don't know why looped 
        
     
        
        
    
    return 0;
    
}